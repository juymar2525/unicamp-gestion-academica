"""Interfaces PySide6."""
